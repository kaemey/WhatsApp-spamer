import requests # type: ignore
import time
import pandas # type: ignore
import subprocess
import datetime
import random
import pyautogui # type: ignore
import webbrowser
from urllib.parse import quote

yandex_token = ''

def sendMessageInWhatsApp(phone, message):
    webbrowser.open(f"https://web.whatsapp.com/send?phone={phone}&text={quote(message)}")
    time.sleep(30)
    pyautogui.press("enter")
    time.sleep(3)
    pyautogui.hotkey("ctrl", "w")
    time.sleep(3)
    pyautogui.press("enter")

def logger(phone, text):
    dt = datetime.datetime.now()
    filename = "log"+str(dt.day)+"-"+str(dt.month)+".xlsx"

    try:
        df = pandas.read_excel(filename)
    except:
        data = {
            "Время": [],
            "Телефон": [],
            "Сообщение": []
        }

        df = pandas.DataFrame(data)

    times = df["Время"]
    phones = df["Телефон"]
    messages = df["Сообщение"]

    times = pandas.concat([times, pandas.Series([str(dt)])], ignore_index=True)
    phones = pandas.concat([phones, pandas.Series([phone])], ignore_index=True)
    messages = pandas.concat([messages, pandas.Series([text])], ignore_index=True)

    data = {
        "Время": times,
        "Телефон": phones,
        "Сообщение": messages
    }

    df = pandas.DataFrame(data)

    with pandas.ExcelWriter(filename, mode="w", engine="xlsxwriter") as writer:
        df.to_excel(writer, sheet_name='Sheet1')
    

#Функция выполнения команд в консоли
def run_command(cmd):
    result = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    return result.stdout.replace('\n', '')

def change8to7inPhone(phone):
    if phone.find('8') == 0:
        return phone.replace('8', '+7', 1)
    if phone.find('7') == 0:
        return phone.replace('7', '+7', 1)
    if phone.find('9') == 0:
        return "+7"+phone
    return phone

#Функция получения неотмеченного телефона в Excel файле
def getPhoneFromExcelFile(filepath):
    # Читаем данные из Excel
    df = pandas.read_excel(filepath)
    phone = ''
    # Перебираем отметки, находя 0, пишем 1 и записываем телефон
    for i in range(0, len(df["Отметка"])):
        if df["Отметка"][i] == 0:
            df.loc[i, "Отметка"] = 1
            phone = str(df["Телефон"][i])
            
            if phone.find('375') == 0:
                df.loc[i+1, "Отметка"] = 1
                phone = str(df["Телефон"][i+1])
                
            break
    
    data = {
        "ФИО": df["ФИО"],
        "Телефон": df["Телефон"],
        "Отметка": df["Отметка"]
    }

    df = pandas.DataFrame(data)

    with pandas.ExcelWriter(filepath, mode="w", engine="xlsxwriter") as writer:
        df.to_excel(writer, sheet_name='Sheet1')

    #Возвращаем телефон
    phone = change8to7inPhone(phone)
    return phone

#Функция, выполняющая команду для получения яндекс токена для YandexGPT
def getTokenYandexGPT():
    return run_command('yc iam create-token')

#Функция для выполнения запроса к YandexGPT
def YandexGPTRequest(iam_token, folder_id, user_text, gpt_role, temperature = 0.3, model='yandexgpt-lite/latest'):    
    URL = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion"
    # Собираем запрос
    data = {}
    # Указываем тип модели
    data["modelUri"] = f"gpt://{folder_id}/{model}"
    # Настраиваем опции
    data["completionOptions"] = {"temperature": temperature, "maxTokens": 1000}
    # Указываем контекст для модели
    data["messages"] = [
        {"role": "system", "text": gpt_role},
        {"role": "user", "text": f"{user_text}"},
    ]
    
    # Отправляем запрос
    response = requests.post(
        URL,
        headers={
            "Accept": "application/json",
            "Authorization": f"Bearer {iam_token}"
        },
        json=data,
    ).json()

    #Проверяем результат
    if 'error' in response:
        print(response)
        return False
    else:
        return response

#Получаем ответ от YandexGPT
def getTextFromYandex(token):
    text = "Здравствуйте! Меня зовут Максим, я менеджер компании СДЕК. Хочу предложить вам сотрудничество с нашей компанией. Заключив договор, Вы сможете увеличить прибыль и расширить свою клиентскую базу.. Договор абсолютно бесплатный. Основные преимущества: Отправки и получения будут дешевле по сравнению с отправками физических лиц примерно на 40%. У вас будет личный закреплённый менеджер. Бесплатная упаковка: пакеты А3, А4 и конверты А4. Оплата один раз в месяц. Вам станут доступны такие услуги, как: наложенный платеж, частичная доставка, страхование груза, доставка до маркетплейсов. Кроме того мы предоставляем услуги фулфилмента. Буду рад ответить на все ваши вопросы."
    role = "Немного измени текст, смысл оставь тот же"
    
    return YandexGPTRequest(iam_token = token, folder_id = "b1gnku2eka2047l63s69", user_text = text, gpt_role = role )['result']['alternatives'][0]['message']['text']

yandex_token = getTokenYandexGPT()

tphone = ''

a = 0

while a < 60:
    a+=1
    tphone = getPhoneFromExcelFile('all.xlsx')
    if tphone == '':
        print("Номера закончились или произошла ошибка, конец работы")
        break

    text = getTextFromYandex(yandex_token)
    sendMessageInWhatsApp(phone=tphone, message=text)
    print("Сообщение отправлено на телефон " + tphone)
    time.sleep(random.randint(300,600))